package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Login extends AppCompatActivity {

    private EditText edtEmail;
    private EditText edtPassword;
    private Button btnSingin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnSingin = findViewById(R.id.btnSignin);



    }

    public void next(View view){
        Intent it = new Intent(getApplicationContext(),Register.class);
        startActivity(it);

    }

    public void nextM(View view){
        Intent it = new Intent(getApplicationContext(),Menu.class);
        startActivity(it);

    }

    public void cruck(View view){
        if(edtEmail.equals("")){
            btnSingin.setError("BUGO CARLAHO");
        }
    }



}